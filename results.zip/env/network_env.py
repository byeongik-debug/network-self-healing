"""RL-compatible interface without any learning or reward implementation."""

from __future__ import annotations

from copy import deepcopy
import random
from typing import Any, Literal

from config.scenarios import EVAL_SCENARIOS, TRAIN_SCENARIOS
from .actions import ACTIONS, ActionSpec
from .simulator import NetworkSimulator


Split = Literal["train", "eval"]


class NetworkEnv:
    """Deterministic VLAN recovery environment with a fixed discrete action space."""

    def __init__(
        self,
        split: Split = "train",
        scenario: str | None = None,
        max_steps: int = 30,
    ) -> None:
        if split not in ("train", "eval"):
            raise ValueError("split must be 'train' or 'eval'")
        self.split = split
        self.requested_scenario = scenario
        self.max_steps = max_steps
        self.simulator = NetworkSimulator()
        self._rng = random.Random()
        self._initial_faulty_state: dict[str, Any] = {}
        self._scenario_name = ""
        self._metrics: dict[str, int] = {}
        self._last_diagnostics: dict[str, dict[str, bool]] = {}
        self._terminated = False
        self._truncated = False

    def reset(self, seed: int | None = None) -> tuple[dict[str, Any], dict[str, Any]]:
        self._rng.seed(seed)
        catalog = TRAIN_SCENARIOS if self.split == "train" else EVAL_SCENARIOS
        scenario_name = self.requested_scenario or self._rng.choice(sorted(catalog))
        if scenario_name not in catalog:
            raise ValueError(f"Unknown {self.split} scenario: {scenario_name}")
        self.simulator.reset()
        for mutation in catalog[scenario_name]:
            self.simulator.apply_fault(mutation)
        self._scenario_name = scenario_name
        self._initial_faulty_state = self.simulator.snapshot()
        self._metrics = {
            "steps": 0,
            "diagnostic_actions": 0,
            "configuration_changes": 0,
            "rollbacks": 0,
            "invalid_actions": 0,
        }
        self._last_diagnostics = self.simulator.connectivity()
        self._terminated = False
        self._truncated = False
        return self.get_observation(), {"split": self.split}

    def step(self, action: int) -> tuple[dict[str, Any], float, bool, bool, dict[str, Any]]:
        if self._terminated or self._truncated:
            raise RuntimeError("Episode has ended; call reset() before step().")
        self._metrics["steps"] += 1
        info: dict[str, Any] = {"valid_action": True}
        spec = self._get_action(action)
        if spec is None:
            self._metrics["invalid_actions"] += 1
            info.update({"valid_action": False, "error": "action must be a valid integer action id"})
        else:
            self._apply_action(spec, info)
        self._truncated = not self._terminated and self._metrics["steps"] >= self.max_steps
        info["policy_healthy"] = self.simulator.is_policy_healthy()
        reward = self.calculate_reward()
        return self.get_observation(), reward, self._terminated, self._truncated, info

    def calculate_reward(self) -> float:
        """Extension point for researcher-owned reward design."""
        return 0.0

    def get_observation(self) -> dict[str, Any]:
        return {
            "ports": self.simulator.observable_ports(),
            "link_states": {
                f"{switch}:{port}": bool(settings["link_up"])
                for switch, ports in self.simulator.ports.items()
                for port, settings in ports.items()
            },
            "connectivity": deepcopy(self._last_diagnostics),
            "step_count": self._metrics.get("steps", 0),
        }

    def get_valid_actions(self) -> list[dict[str, Any]]:
        return [
            {
                "id": action.id,
                "kind": action.kind,
                "switch": action.switch,
                "port": action.port,
                "vlan": action.vlan,
                "allowed": action.allowed,
            }
            for action in ACTIONS
        ]

    def check_connectivity(self) -> dict[str, dict[str, bool]]:
        self._last_diagnostics = self.simulator.connectivity()
        return deepcopy(self._last_diagnostics)

    def get_metrics(self) -> dict[str, Any]:
        return {**self._metrics, "policy_healthy": self.simulator.is_policy_healthy()}

    def _get_action(self, action: int) -> ActionSpec | None:
        if isinstance(action, bool) or not isinstance(action, int) or action < 0 or action >= len(ACTIONS):
            return None
        return ACTIONS[action]

    def _apply_action(self, action: ActionSpec, info: dict[str, Any]) -> None:
        if action.kind == "diagnose":
            self._metrics["diagnostic_actions"] += 1
            self.check_connectivity()
        elif action.kind == "set_access_vlan":
            self.simulator.set_access_vlan(action.switch or "", action.port or "", action.vlan or 0)
            self._metrics["configuration_changes"] += 1
            self.check_connectivity()
        elif action.kind == "set_trunk_vlan":
            self.simulator.set_trunk_vlan(
                action.switch or "", action.port or "", action.vlan or 0, bool(action.allowed)
            )
            self._metrics["configuration_changes"] += 1
            self.check_connectivity()
        elif action.kind == "rollback":
            self.simulator.restore(self._initial_faulty_state)
            self._metrics["rollbacks"] += 1
            self.check_connectivity()
        elif action.kind == "declare_done":
            self._terminated = True
            info["recovery_success"] = self.simulator.is_policy_healthy()

